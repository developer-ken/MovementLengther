﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using HardwareInterface;
using OpenCvSharp;

namespace MovementLengther
{
    static class Program
    {
        public static Queue<Action> TaskList;
        static void Main(string[] args)
        {
            TaskList = new Queue<Action>();
            StreamWriter swA = new StreamWriter("resultA.csv")
                 , swB = new StreamWriter("resultB.csv"),
                swResult = new StreamWriter("resultFinal.csv");

            Console.WriteLine("Simple pendulum mesurement system");

            Console.WriteLine("Connecting to cam...");

            IPCamera camA = new IPCamera("http://192.168.66.3:8080/?action=stream");
            camA.Init();

            IPCamera camB = new IPCamera("http://192.168.66.2:8080/?action=stream");
            camB.Init();

            Console.WriteLine("Loading detectors...");

            Detector detA = new(),
                detB = new();
            Console.WriteLine("**** Press Enter To Start ****");
            Console.ReadLine();
            new Thread(new ThreadStart(() => { detB.Alg(camB); })).Start();
            new Thread(new ThreadStart(() => { detA.Alg(camA, true); })).Start();

            Console.WriteLine("Loading DO...");

            DataOrganizer dato = new DataOrganizer();
            detA.OnNewResultArrive += dato.TriggerA;
            detB.OnNewResultArrive += dato.TriggerB;

            detA.OnLeftHit += dato.CountA;
            detB.OnLeftHit += dato.CountB;

            
            detA.OnMovement += (obj) =>
            {
                swA.WriteLine(obj.X + "," + obj.Y);
                swA.Flush();
            };
            detB.OnMovement += (obj) =>
            {
                swB.WriteLine(obj.X + "," + obj.Y);
                swB.Flush();
            };
            

            dato.OnResultFrame += Dato_OnResultFrame;
            dato.OnResultFrame += (obj) =>
            {
                swResult.WriteLine((180 * obj.Angle / Math.PI) + "," + obj.TimeSpan + "," + obj.LineLen);
                swResult.Flush();
            };
            Console.WriteLine("Thread worker enabled");
            while (true)
            {
                if (TaskList.Count != 0)
                    TaskList.Dequeue()?.Invoke();
            }
        }

        private static void Dato_OnResultFrame(DataOrganizer.Result3D obj)
        {
            Console.WriteLine("Angle:" + 180 * obj.Angle / Math.PI + "\tLen:" + obj.LineLen);
        }

        static Point Center(this Rect rect)
        {
            return rect.BottomRight - rect.TopLeft;
        }

        static double ConnerDist(this Size size)
        {
            return Math.Sqrt(size.Width * size.Width + size.Height * size.Height);
        }

        static double Distance(this Point point)
        {
            return Math.Sqrt(point.X * point.X + point.Y * point.Y);
        }

        static List<Rect> Clone(this List<Rect> list)
        {
            var result = new List<Rect>();
            result.AddRange(list);
            return result;
        }
    }
}